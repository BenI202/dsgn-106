<video src="../_static/chapter7/4-working-with-stakeholders.mp4" width="640" height="360" controls></video>
